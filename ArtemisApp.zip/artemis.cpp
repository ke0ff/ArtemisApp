/********************************************************************
 *
 *  File name: artemis.cpp
 *
 *  Summary:   This program configures the Artemis PLL
 *              de KE0FF
 *
 *             The serial port is configured for N82, 115200 baud, no parity.
 *
 *  Called via:   artemis <com port>
 *
 *                <com port> number, default is 4
 *
 *   If no COM port is specified at the command line, the user is prompted
 *      for one (ENTER selects the default).
 *
 *******************************************************************/

/********************************************************************
 *
 * Revision History:
 * V0.1
 *    04/03/25 jmh: Added set channel and pgm channel cmds
 *                  Added file load command support for "t" and "P" commands.  Each have their
 *                      own line delay set at compile-time.
 *                  Added trap to skip registers above 79 during load process.  Speeds the file
 *                      transfer.
 * V0.0
 *    04/02/25 jmh: Mostly feature complete with basic funtionality tested with dummy Artemis
 *                  File commands work, as do "t" and debug.  Some flourishes remain, but with
 *                      a sucessful bench test, this app will be ready for limited beta test.
 *    04/01/25 jmh: No foolin!  A new PC app to drive the Artemis PLL, based on the RDU900 app.
 * 
 *    04/01/25 jmh: copied project from 900CAT & SerialTest (with thanks to DianaS.)
 *******************************************************************/

#include "stdafx.h"

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <sys/timeb.h>

#include "pcserial.h"
#include "comm.h"
#include "scrndisp.h"
#include "scrnattr.h"
#include "uxpll.h"

#define VERSION     "0.1"

#define CR          0x0d                 /* ASCII carriage return */
#define ESC         0x1b                 /* ASCII ESCape character */
#define BEL         0x07                 /* ASCII BEL character */
#define CMD_INIT    127
#define IPL_CMD     0xff
#define LAST_REG    79

unsigned char lastScrollRowUsed;
unsigned char scrollRow;
unsigned char scrollCol;
#define MAX_IBUF    255
char    ibuf[MAX_IBUF];
bool    got_cr;
#define MAX_STBUF    32
char    stbuf[MAX_STBUF+10];
bool    got_stcr;
bool    supr_cr;                        /* supress cr flag */
char    srow;                           /* next serial output row */
char    ci;                             /* byte from process_stat */

// ==========  rig status static storage -- file local scope


int     du_flags;

char    def_flnm[] = { "ticsexp.txt" };
char get_hex(char* s);
void display_dbar(char width);
char upcase(char c);
bool is_num(char c);
char press_any_key(bool escmsg);
char get_serial(char srow);
void clr_serial_window(void);
void wait_ms(short int delay);
bool alive_timer_sec(char delay, bool set);

static void redraw_screen(int comm_port_num, bool autol);
static void help_screen(void);
void disp_stat(char cmd);
void file_cmd(int cmd);
bool get_ini(int* comp, bool* autol, long* baudr);
void put_ini(int comp, bool autol, long baudr);
char process_RXD(char cmd, char row);
void puts_rts(char* string);
//void put_namestr(char* sptr);
static void proc_stat(void);


/********************************************************************
 *
 * Function: main
 *
 * Requirements Summary:  Initialize the PC serial port as required
 *      by the program's input parameters and print received bytes
 *      on the screen in hex format.
 *
 * Return value: normal DOS exit
 *
 * Limitations:
 *
 * Notes:
 * Communitcates with operator and target radio to compute and exchange
 *   config data.
 *
 * Revision History:
 *    07-15-22 jmh:  creation date - copied from UXFF application for adaptation
 *                   for the Artemis RDU Clone
 *    01-20-21 jmh:  creation date - copied from SerialTest, modified for UXFF
 *
 *******************************************************************/
int _tmain(int argc, _TCHAR* argv[])
{
    bool  autoload = false;         /* autoload flag */
    bool  ini_save = false;         /* ini file save enable */
    bool  ini_load = false;         /* ini file load enable */
    bool  ipl;                      /* initial start flag */
    bool  iplt;                     /* initial time start flag */
    bool  abort;                    /* true to exit program */
    bool  dead_flag = false;        /* true if no device comms */
    bool  ib;                       /* temp bool */
    bool  data_update = true;       /* internal data updated by user if true */
    long  baud_rate;                /* com port baud rate, no default */
    short int test_count = 0;
    int   com_port = 0;             /* com port id (defaults to COM1) */
    int   parity;                   /* com port parity (defaults to NO_PARITY) */
    char  key;                      /* key pressed on the PC keyboard */
    char  input_str[20];
    //    __timeb64 curr_time_sec;  /* current time in seconds */
    __timeb64 tx_time_sec;          /* transmit time in seconds */
    char obuf[80];                  /* serial tx buffer */
    char iptr;                      /* serial RX index */
    char *sptr;                     /* serial RX index */
    int  i;                         /* temp */

    srow = SERIAL_ROW;              /* ipl-init srow */
    init_screen((unsigned short)WINDOW_WIDTH_IN_CHARS, (unsigned short)WINDOW_LENGTH_IN_LINES);
//    set_text_font(1);
    fflush(stdin);
     
    set_text_color(LABEL_COLOR, BACK_COLOR);
    printf("Artemis PC Interface version %s %c2025 by Joseph M. Haas, KE0FF\n\n", VERSION, CPYRT);

    file_cmd(IPL_CMD);
    if (argc > 1) {
        com_port = atoi(argv[1]);
    }
    if ((argc < 1) || (com_port == 0)) {
        // If no comport selected at command line, ask user to select one here...
        printf("Usage:  apll <com port> <A>utoload <I>ni create ini<O>verride\n\n");
        printf("        where:   <com port> defaults to 4\n");
        printf("                 <A> defaults to off\n");
        printf("                 <I> enables ini file creation\n");
        printf("                 <O> disables ini file load\n");
//        printf("%d, %d, %d\n",sizeof(int), sizeof(char), sizeof(word));
/*        gopos(MENU_ROW_10 + 1, 1);
        printf("012345678901234567890123456789012345678901234567890123456789012345678901234567890\n");
        for(i=128; i<207; i++) printf("%c", i);
        printf("\n");
        for (i = 208; i < (255); i++) printf("%c", i); //*/

        set_text_color(INPUT_COLOR, BACK_COLOR);
        printf("\nEnter COM port (ENTER to accept default): ");
        clr_to_eol();
        gets_s(input_str, sizeof(input_str));
        com_port = atoi(input_str);
        if (!com_port) {
            com_port = 4;                                       // no or "0" entry, select default
        }
    }
    set_text_color(LABEL_COLOR, BACK_COLOR);
    if (argc > 2) {
        if (upcase(*argv[2]) == 'A') autoload = true;
    }
    if (argc > 3) {
        if (upcase(*argv[2]) == 'I') ini_save = true;
    }
    if (argc > 4) {
        if (upcase(*argv[2]) == 'O') ini_load = false;
    }

    baud_rate = 9600L;
    if (ini_load) {
        ib = get_ini(&com_port, &autoload, &baud_rate);         // see if there is an ini file to override
        if (!ini_save) ini_save = ib;                           // ini_save id forced at command line or if ini file present
    }
    iptr = 0;                                                   // init serial RX array
    parity = NOPARITY;

    if (configCommPort(com_port, baud_rate, parity, 8, ONESTOPBIT) ) {
        redraw_screen(com_port, autoload);

        _ftime64_s(&tx_time_sec);
        lastScrollRowUsed = SCROLL_ROW;
        scrollRow = SCROLL_ROW;
        scrollCol = 1;
        abort = false;
        ipl = true;
        iplt = 1;
        disp_stat(0x7f);                                        // initial display of radio config status
        disp_stat(0);                                               // initialize display of radio config status

        sptr = ibuf;
        process_RXD(0, CMD_INIT);
        puts_rts((char*)"info 10\r");                               // ping radio

        while ( !abort ) {
            // process radio serial data
            proc_stat();
            if (ipl) {                                                              // status field is "dead-front" if ipl (or dead_flag)
                gopos(PROG_ID_ROW, TR_STATUS_COL);
                set_text_color(WARN_COLOR, BACK_COLOR);
                printf(".. . ...");
                ipl = false;
            }
            // Process operator command input
            if (_kbhit() != 0) {                                                    // operator command loop...
                key = _getch();
                set_text_color(INPUT_COLOR, BACK_COLOR);                            // all input is INPUT color
                gopos(INPUT_ROW + 1, 1);                                            // clean input area before each command
                clr_to_eol();
                gopos(INPUT_ROW, 1);
                clr_to_eol();
                switch (key) {
                    case ESC :
                        // end program
                        abort = true;
                        break;

                    case '?':                 // < > help screen
                        // help screen
                        help_screen();
//                        redraw_screen(com_port, autoload);
//                       srow = SERIAL_ROW;
//                        data_update = true;                                                 // no data changed, but update the status field
//                        break;

                    case ' ':                 // < > redraw screen, status on
                        // redraw screen
                        redraw_screen(com_port, autoload);
                        disp_stat(0x7f);
                        srow = SERIAL_ROW;
                        gopos(srow, 1);
                        data_update = true;                                                 // no data changed, but update the status field
                        process_RXD('\0', CMD_INIT);
                        break;

                    case 'c':
                        clr_to_eol();
                        gopos(INPUT_ROW, 1);
                        _cputs("Set CH#: ");
                        gets_s(obuf, 20);
                        gopos(INPUT_ROW, 1);
                        clr_to_eol();
                        sscanf_s(obuf, "%d", &i);
                        sprintf_s(obuf, "%d\r", i);
                        puts_rts(obuf);
                        break;

                    case 'G':                 // debug flash - !!! need to send the target output to a file !!!
                        sprintf_s(obuf, "z f\r");
                        puts_rts(obuf);
                        break;

                    case 'g':                 // debug temp ch
                        sprintf_s(obuf, "z\r");
                        puts_rts(obuf);
                        break;

                    case 't':
                        sprintf_s(obuf, "t\r");
                        puts_rts(obuf);
                        break;

                    case 'A':                 // Query ADC raw values
                    case 'a':
                        sprintf_s(obuf, "%c\r", key);
                        puts_rts(obuf);
                        break;

                    case 'B':
                        // baud rate query
                        printf("Current Baud Rate = %u\n", baud_rate);
                        break;

                    case 'Q':
                        // reset FSEL
                        sprintf_s(obuf, "q\r");
                        puts_rts(obuf);
                        break;

                    case 'h':
                        // help
                        sprintf_s(obuf, "?\r");
                        puts_rts(obuf);
                        break;

                    case 'Z':
                        // file command
                        file_cmd(0);
                        data_update = true;
                        break;

                    case '=':
                        // quick-send file command
                        file_cmd((int)'=');
                        data_update = true;
                        break;

                    case 'P':
                        // pgm ch
                        clr_to_eol();
                        gopos(INPUT_ROW, 1);
                        _cputs("PGM CH#: ");
                        gets_s(obuf, 20);
                        gopos(INPUT_ROW, 1);
                        clr_to_eol();
                        sscanf_s(obuf, "%d", &i);
                        sprintf_s(obuf, "P%d\r", i);
                        puts_rts(obuf);
                        break;

                    case 'V':
                        // set VOL
                        sprintf_s(obuf, "V\r");
                        puts_rts(obuf);
                        break;

                    case '\r':
                    case '\n':
                        // query temps
                        sprintf_s(obuf, "\r");
                        puts_rts(obuf);
                        break;

                    default:
                        _cprintf("%cInvalid cmd.",BEL);
                        break;
                }
                if (data_update) {
                    disp_stat(0);                              // display status <deprecated>
                    data_update = false;
                }

            }
        }
        closeCommPort();
        if (ini_save) {
            put_ini(com_port, autoload, baud_rate);
        }
    }
    else {
        printf("Error initializing COM port.\r\n");
        printf("Press any key to continue... \n");
        while (!(_getch()));
        help_screen();
    }
    return 0;
}
#undef TX_RATE_MS
#undef MS_PER_SEC

///////////////////////////////////
//  process target serial characters
///////////////////////////////////
static void proc_stat(void) {
    char  ch;                       /* byte read from com port */

    // process radio serial data
    if (serialByteIn(&ch)) {                                // grab serial characters from radio
        srow = process_RXD(ch, srow);                       // process datastream and separate into "#$" and free-text responses
/*        if (got_stcr) {
            ci = process_STAT();                            // process status msg
            if (du_flags) {
                disp_stat(0);                               // update display
            }
            got_stcr = false;
            supr_cr = true;
        }*/
    }
    return;
}

///////////////////////////////////
//  redraw_screen
///////////////////////////////////
static void redraw_screen(int comm_port_num, bool autol)
{
    unsigned char row;

    clr_screen();
    set_text_color(LABEL_COLOR, BACK_COLOR);
    for (row=1; row<=WINDOW_LENGTH_IN_LINES; row++) {
        // set background color for window
        gopos(row, 1);
        clr_to_eol();
    }
    gopos(TOP_ROW, 1);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    printf("%c", ULDBAR);
    display_dbar(WINDOW_WIDTH_IN_CHARS - 2);

    gopos(PROG_ID_ROW, 1);
    printf("%c ", DPIPE);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    _cprintf("Artemis Config Tool version %s on COM %d -- ESC to quit", VERSION, comm_port_num);
    gopos(PROG_ID_ROW+1, 1);
    printf("%c", LDPIPE);
    display_dbar(WINDOW_WIDTH_IN_CHARS - 2);
    printf("%c", RDPIPE);

    gopos(MENU_ROW_1, 1);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    printf("%c", LDPIPE);
    display_dbar(WINDOW_WIDTH_IN_CHARS - 2);
    printf("%c", RDPIPE);
    gopos(MENU_ROW_2, 3);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    _cputs("<?> App Help      <space> Re-draw      <B> Baud rate query        <Z> File Commands");
    clr_to_eol();
    gopos(MENU_ROW_3, 3);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    _cputs("<h> PLL help        <A/a> ADC raw      <Q> re-sync FSEL           <=> quick load");
    clr_to_eol();
    gopos(MENU_ROW_4, 3);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    _cputs("<CR> query status   <t> set test CH    <P> Prog test to FLASH     <V> PLL Version");
    clr_to_eol();
    clr_to_eol();
    gopos(MENU_ROW_2, 1);
    printf("%c", DPIPE);
    gopos(MENU_ROW_3, 1);
    printf("%c", DPIPE);
    gopos(MENU_ROW_4, 1);
    printf("%c", DPIPE);
    gopos(MENU_ROW_5, 1);
    printf("%c", DPIPE);

    gopos(MENU_ROW_2, WINDOW_WIDTH_IN_CHARS);
    printf("%c", DPIPE);
    gopos(MENU_ROW_3, WINDOW_WIDTH_IN_CHARS);
    printf("%c", DPIPE);
    gopos(MENU_ROW_4, WINDOW_WIDTH_IN_CHARS);
    printf("%c", DPIPE);
    gopos(MENU_ROW_5, WINDOW_WIDTH_IN_CHARS);
    printf("%c", DPIPE);

    // T/R status window default & window bars
    gopos(PROG_ID_ROW, TR_STATUS_COL);
    set_text_color(WARN_COLOR, BACK_COLOR);
    printf(".. . ...");
    gopos(PROG_ID_ROW, TR_STATUS_WIN_COL);
    printf("%c", DPIPE);
    gopos(PROG_ID_ROW+1, TR_STATUS_WIN_COL);
    printf("%c", UDBAR);
    display_dbar(WINDOW_WIDTH_IN_CHARS - TR_STATUS_WIN_COL - 1);
    printf("%c", RDPIPE);

    gopos(TOP_ROW, TR_STATUS_WIN_COL);
    printf("%c", DDBAR);
    display_dbar(WINDOW_WIDTH_IN_CHARS - TR_STATUS_WIN_COL - 1);
    printf("%c", URDBAR);
    gopos(PROG_ID_ROW, WINDOW_WIDTH_IN_CHARS);
    printf("%c", DPIPE);

    gopos(MENU_ROW_5, 1);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    printf("%c", LLDBAR);
    display_dbar(WINDOW_WIDTH_IN_CHARS - 2);
    gopos(MENU_ROW_5, WINDOW_WIDTH_IN_CHARS);
    printf("%c", LRDBAR);

}

///////////////////////////////////
//  help_screen
///////////////////////////////////
static void help_screen(void)
{
    char    srow = MENU_ROW_1;
    char    c = '\0';                              // temp char
#define HELP_ROWS (BOTTOM_ROW - LAST_MENU_ROW)


//    unsigned char row;

    clr_screen();
    gopos(PROG_ID_ROW, 1);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    _cprintf("Artemis Config Tool HELP, page 1 of 1 version %s", VERSION);
    _cprintf(" %c2025 by Joseph M. Haas, KE0FF", CPYRT);

    gopos(MENU_ROW_2, 1);
    set_text_color(LABEL_COLOR, BACK_COLOR);
//  _cputs("12345678901234567890123456789012345678901234567890123456789012345678901234567890123\n");    // ruler line
    _cputs("This software supports the Artemis PLL project.  A 2.5 - 15 GHz synthesizer based\n");
    _cputs("  on the LMX2594 device.  This app handles data downloads and command line interface\n");
    _cputs("  with the ATtiny3217 MCU controller on the Artemis board.\n");
    _cputs("\n");
    _cputs("  9600 baud, N81, 3.3V TTL serial connection is used for communication with the MCU.\n");
    _cputs("\n");
    _cputs("First open this software and select a valid COM port. Then connect the Artemis\n");
    _cputs("  to the COM port and apply power to the Artemis (if not already).  The file commands\n");
    _cputs("  can optionally be used to load a PLL configuration from a TICSpro export file.  Use\n");
    _cputs("  't' to test the file or 'P' to program a channel.  The '=' command is the quick-load\n");
    _cputs("  command which allows the opertor to preset the filename and load it quickly when\n");
    _cputs("  performing TICSpro configuration 'tweaks'.\n");
    _cputs("\n");
    _cputs("  't' or 'Pn' commands may be embedded in the text load file to allow automatic test\n");
    _cputs("  or programming.  In this way, multiple channels may be contained in a single file.\n");
    _cputs("  for mass-programming.\n");

    _cputs("\n");

//    clr_to_eol();
//    set_text_color(LABEL_COLOR, BACK_COLOR);
//    gopos(BOTTOM_ROW + 1, 1);
//    c = press_any_key(true);
//    if (c == ESC) return;
/*
    clr_screen();
    gopos(PROG_ID_ROW, 1);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    _cprintf("UXFFront Config Tool HELP, page 2 of 5");

    gopos(MENU_ROW_1, 1);
    set_text_color(LABEL_COLOR, BACK_COLOR);
//  _cputs("12345678901234567890123456789012345678901234567890123456789012345678901234567890123\n");    // ruler line
    _cputs("Application Window Overview\n\n");
    _cputs("The 'mid' area is where user input is displayed, with radio serial responses in the\n");
    _cputs("  lower area of the screen (displays serial responses which 'roll over' previous\n");
    _cputs("  responses.  It will provide information as to the health of the radio connection,\n");
    _cputs("  but not much operator attention is required to the results.\n");
    _cputs("\n");
    _cputs("Use the 'V'erify command to compare the radio FLASH data to the configux data\n");          // line 4
    _cputs("  array. This will validate that the FLASH data was saved properly.  The radio\n");         // line 5
    _cputs("  is now ready for service.\n");                                                            // line 6
    _cputs("\n");                                                                                       // line 7
    _cputs("The files are text format, so the '.txt' extention is recommended.  Even though the\n");    // line 8
    _cputs("  files are in text format, the file data is not easily modified by hand.  The user\n");    // line 9
    _cputs("  may add comments to specific areas of the data file.  These areas are documented\n");     // line 10
    _cputs("  in the saved data files.\n");                                                             // line 11
    _cputs("\n");                                                                                       // line 12
    _cputs("Command line arguments:\n");                                                                // line 13
    _cputs("\n");                                                                                       // line 14
    _cputs("  Useage: configux <com> ; <autoload> ; <ini> ; <disable ini load>\n");                     // line 15
    _cputs("    <com> is the integer COM port# to use for this application.  If invalid,\n");           // line 16
    _cputs("        the application will exit through this help screen sequence.\n");                   // line 17
    _cputs("    <autoload> '1' enables autoload, '0' disables.  In either case, the user\n");           // line 18
    _cputs("        may change the autoload status in the main command screen.\n");                     // line 19
    _cputs("    <ini> 'I' enables the creation of an .ini file.  If an ini file is already\n");         // line 20
    _cputs("        present, it will be updated on exit and the <ini> argument has no effect.\n");      // line 21
    _cputs("    <disable ini load> 'O' disables the .ini file load.  ini save on exit will\n");         // line 22
    _cputs("        still occur.\n");                                                                   // line 23
    _cputs("\n");                                                                                       // line 24
    _cputs("General Notes:\n");                                                                         // line 25
    _cputs("\n");                                                                                       // line 26
    _cputs("This application is organized as a key-press driven command processor.  The cmds\n");       // line 27
    _cputs("  are single character, case-sensitive keypresses.  The user is prompted for\n");           // line 28
    _cputs("  further input as required for a given command.  These commands are listed in\n");         // line 29
    _cputs("  the upper area of the console window.\n");                                                // line 30

    clr_to_eol();
    set_text_color(LABEL_COLOR, BACK_COLOR);
    gopos(BOTTOM_ROW + 1, 1);
    c = press_any_key(true);
    if (c == ESC) return;


    clr_screen();
    gopos(PROG_ID_ROW, 1);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    _cprintf("UXFFront Config Tool HELP, page 5 of 5");

    gopos(MENU_ROW_1, 1);
    set_text_color(LABEL_COLOR, BACK_COLOR);
    //_cputs("12345678901234567890123456789012345678901234567890123456789012345678901234567890123\n");    // ruler line
    _cputs("This is a checklist of commands to configure a radio from scratch:\n");
    _cputs("\n");
    _cputs("        'r': Enter the RX frequency.\n");
    _cputs("        't': Enter the TX frequency.\n");
    _cputs("        'p': Enter the TX power (1 = hi, 0 = low).\n");
    _cputs("        'v': Enter the RX audio level (start with 170).\n");
    _cputs("        'q': Enter the primary squelch value (start with 30).\n");
    _cputs("        'Q': Enter the secondary squelch value (same value as 'q' if not used).\n");
    _cputs("        'S': Send config to radio.\n");
    _cputs("        'W': Write config to radio FLASH.\n");
    _cputs("        'V': Verify config.\n");
    _cputs("\n");
    _cputs("The 'v', 'q', and 'Q' commands may require some iteration to center on the desired\n");
    _cputs("  values due to variations in location and equipment.\n");
    _cputs("\n");
    _cputs("\n");
    _cputs("See https://github.com/ke0ff/UXFFconfigurator for the latest version of this\n");
    _cputs("  program and other support resources for this application and the UXFF modules.\n");
*/
    clr_to_eol();
    set_text_color(LABEL_COLOR, BACK_COLOR);
    gopos(BOTTOM_ROW + 1, 1);
    press_any_key(false);
    return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// file_cmd() sets default filename or transfers that file to the COM port
//  cmd == IPL_CMD, '=', or NULL
//-----------------------------------------------------------------------------
void file_cmd(int cmd) {
    char    key;
    char    i;
    char    c;
    int     eofreg = 0;
    int     tdly;
    int     ii;
#define LINE_MAX3    100
    char    in_str[LINE_MAX3];
    static  char    nam_str[80];
    char* sptr;
    char* dptr;

    FILE    *filename;
    errno_t err;
    char*   err2;

    switch (cmd) {
    default:
    case IPL_CMD:   // ipl, set default filename
        sptr = def_flnm;
        dptr = nam_str;
        do {
            *dptr++ = *sptr++;
        } while (*sptr);
        *dptr = '\0';
        break;

    case '\0':
    case '=':
        clr_to_eol();
        //    set_text_color(LABEL_COLOR, BACK_COLOR);
        gopos(INPUT_ROW, 1);
        if (cmd != '=') {
            _cputs("File (N)ame, (L)oad, (Q)uery filename, or (A)bort: ");
            do {
                key = _getch();
            } while (!key);
            key = upcase(key);
            if ((key == 'N') || (key == 'L')) {
                gopos(INPUT_ROW, 1);
                clr_to_eol();
                _cputs("Enter filename (80 chr, max): ");
                //        set_text_color(DATA_COLOR, BACK_COLOR);
                gets_s(nam_str, sizeof(nam_str));
                gopos(INPUT_ROW, 1);
                clr_to_eol();
                _cputs(nam_str);
            }
        }
        else {
            key = '=';
        }
       switch (key) {
        case 'L':
        case '=':
            err = fopen_s(&filename, nam_str, "r");
            if (!err) {
                i = 0;
                do {
                    err2 = fgets(in_str, LINE_MAX3, filename);
                    if (!err) {
                        //sscanf_s(in_str, "%04x", &eofreg);
                        //                        printf("er:%04x\n", eofreg);
                        gopos(SERIAL_ROW - 3, 1);                           // clear bot cmd row
                        clr_to_eol();
                        //                        set_text_color(ALERT_COLOR, BACK_COLOR);            // set new separator bar
                        c = in_str[0];
                        switch (c) {
                        case 'R':
                            sscanf_s(&in_str[1], "%d", &ii);    // get reg#
                            if (ii <= LAST_REG) {
                                tdly = 2;
                            }
                            else {
                                c = '\0';                       // ignore line if reg# too high
                            }
                            break;

                        case 't':           // set delays per the line command
                            tdly = 50;
                            break;

                        case 'P':
                            tdly = 200;
                            break;

                        default:            // if not a valid load command, ignore
                            c = '\0';
                            break;
                        }
                        if (c) {
                            _cputs(in_str);
                            puts_rts(in_str);
                            timer_ms(tdly, true);
                            while (timer_ms(0, false)) {
                                //proc_stat();            // !!!have proc_stat() return response character and flag if error
                            }
                        }
                    }
                        //                    j = sscanf_s(ibuf, "%08x", &tt);
                        //                    if (i > MAX_PLL) {
                        //                        err = 10;
                        //                    }
                } while (err2 != NULL); // && (eofreg != 0xE0F));
                fclose(filename);
                gopos(SERIAL_ROW - 3, 1);                           // clear bot cmd row
                clr_to_eol();
                printf_s("Done.");
            }
            else {
                printf_s("File not found: %u", err);
                //                press_any_key(false);
            }
            break;

        case 'Q':       // query filename
            gopos(INPUT_ROW, 1);
            clr_to_eol();
            _cputs("Current filename: ");
            //        set_text_color(DATA_COLOR, BACK_COLOR);
            _cputs(nam_str);
            break;

        default:
            break;
        }
    }
    return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// get_ini() loads preferences from configux.ini, if the file is found
//-----------------------------------------------------------------------------
bool get_ini(int* comp, bool* autol, long* baudr) {
    int    i;
#define LINE_MAX1    80
    char    in_str[LINE_MAX1];
    bool    f_ok = false;

    FILE* filename;
    errno_t err;
    char* err2;

    err = fopen_s(&filename, "configux.ini", "r");
    if (!err) {
        err2 = fgets(in_str, LINE_MAX1, filename);
        sscanf_s(in_str, "%u", comp);
        err2 = fgets(in_str, LINE_MAX1, filename);
        sscanf_s(in_str, "%u", &i);
        if (i == 1) {
            *autol = true;
        }else{
            *autol = false;
        }
        err2 = fgets(in_str, LINE_MAX1, filename);
        sscanf_s(in_str, "%u", baudr);
        fclose(filename);
        f_ok = true;
    }
    return f_ok;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// put_ini() saves preferences to configux.ini
//-----------------------------------------------------------------------------
void put_ini(int comp, bool autol, long baudr) {
    int    i;
#define LINE_MAX2    80
    char    in_str[LINE_MAX2];

    FILE* filename;
    errno_t err;
//    char* err2;

    err = fopen_s(&filename, "configux.ini", "w");
    if (!err) {
        i = 0;
        if (autol) i = 1;
        sprintf_s(in_str, "%u\t\t\t\t\t// COM port\n", comp);
        fputs(in_str, filename);
        sprintf_s(in_str, "%u\t\t\t\t\t// autoload\n", i);
        fputs(in_str, filename);
        sprintf_s(in_str, "%u\t\t\t\t// baud rate\n", baudr);
        fputs(in_str, filename);
        fclose(filename);
    }
    return;
}


///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// get_hex() returns hex conversion of two chars at *s
//-----------------------------------------------------------------------------
char get_hex(char* s) {
    char    i;     // temps
    char    j;
    char*   lptr = s;

    i = upcase(*lptr++);
    if ((i < '0') || (i > 'F')) i = '0';    // force to 0 if invalid
    i -= '0';                               // convert to number
    if (i > 9) i -= 'A' - '9' - 1;
    j = upcase(*lptr);
    if ((j < '0') || (j > 'F')) j = '0';    // force to 0 if invalid
    j -= '0';                               // convert to number
    if (j > 9) j -= 'A' - '9' - 1;
    return ((i << 4) | j);
}


///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// display_dbar() sends width# of DBAR characters to screen at current location
//-----------------------------------------------------------------------------
void display_dbar(char width) {
    char    i = width;     // temp

    while (i--) {
        printf("%c", DBAR);
    }
    return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// upcase() returns upper case of c
//-----------------------------------------------------------------------------
char upcase(char c) {
    char    i = c;     // temp

    if ((c >= 'a') && (c <= 'z')) i = c - ('a' - 'A');        // upcase
    return (i);
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// is_num() returns true if character is a decimal digit
//-----------------------------------------------------------------------------
bool is_num(char c) {
    bool    i = false;     // return temp

    if ((c >= '0') && (c <= '9')) i = true;
    return (i);
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// press_any_key() waits for user keypress
//-----------------------------------------------------------------------------
char press_any_key(bool escmsg) {
    char c = '\0';

    set_text_color(DATA_COLOR, BACK_COLOR);
    if (escmsg) {
        _cputs("Press any key to continue, ESC to exit...");
    }else{
        _cputs("Press any key to continue...");
    }
    while (!c) {
        c = _getch();
    }
    return c;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// get_serial() gathers serial input up to timeout.  Displays to console window
//-----------------------------------------------------------------------------
char get_serial(char srow) {
    char    i = 0;     // temps
    char    j;
    char    tilde = 0;
    char    timer = 1;
    char    qbuf[255];

    timer_ms(200, true);
    do {
        if (serialByteIn(&j)) {
            if (tilde) {
                qbuf[i++] = j;
            }
            if (j == '~') {
                tilde = 1;
            }
            if (((j == '\n') || (j == '.')) && (tilde)) {
                timer = 0;
            }
        }
    } while (timer_ms(0, false) && (timer) && (i < 60));
    qbuf[i] = '\0';
    gopos(srow++, 1);
    set_text_color(DATA_COLOR, BACK_COLOR);
    clr_to_eol();
    _cputs(qbuf);
    clr_to_eol();
    if (srow > BOTTOM_ROW) {
        srow = SERIAL_ROW;
    }
    return srow;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// clr_serial_window() clears "serial area" of console window
//-----------------------------------------------------------------------------
void clr_serial_window(void) {
    char    srow;

    for (srow = SERIAL_ROW; srow <= BOTTOM_ROW; srow++) {
        gopos(srow, 1);
        clr_to_eol();
    }
    return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// wait_ms() performs a "lock-down" (nothing else happens) delay.
//  "delay" is in ms.  Upper limit is 999, but a practical limit will be much less.
//      Since the ftime64 resource rolls over at 1000, delay values close to
//      1000 risk latencies causing overrun.  Unfortunately, establishing metrics
//      for such things is difficult, so one must simply guess at an upper limit.
//      750 is my current (first) guess...
//-----------------------------------------------------------------------------

#define MAX_WAIT    750

void wait_ms(short int delay) {
    __timeb64        curr_time_sec;      // current time
    unsigned short   ct;                 // current time
    unsigned short   t;                  // start time
    unsigned short   dt;                 // end (delta) time
    bool             loop = true;        // loop flag

    _ftime64_s(&curr_time_sec);
    t = curr_time_sec.millitm;
    if (delay > MAX_WAIT) {
        dt = t + MAX_WAIT;
    }else{
        dt = t + delay;
    }
    do {
        _ftime64_s(&curr_time_sec);
        ct = curr_time_sec.millitm;
        if (dt > t){
            if ((ct > dt) || (ct < t)) loop = false;
        }else {
            if ((ct > dt) && (ct < t)) loop = false;
        }
    } while (loop);
    return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// timer_ms() sets or tests a ms timer.
//  "delay" is in ms.  Upper limit is 999.  This code depends on the ms time and
//      running seconds count being synchronized in the WIN OS.  No idea if this
//      is true yet...
//
//  Returns FALSE if timer is expired, TRUE if running.
//
//  Call with delay value and SET = true to start timer.
//  Call with delay = "don't care" and SET = false to check timer.
//  Overrun returns as expired timer, but no information is passed to determine
//      the degree of overrun.
//-----------------------------------------------------------------------------

bool timer_ms(short int delay, bool set) {
    __timeb64               curr_time_sec;      // current time
    static time_t           st;                 // modified "julean" sec
    static unsigned short   t;                  // start time (ms)
    static unsigned short   dt;                 // end (delta) time (ms)
    unsigned short          ct;                 // current time (ms)
    bool                    loop = true;        // loop flag

    _ftime64_s(&curr_time_sec);
    if (set) {
        st = curr_time_sec.time;                                // save running seconds
        t = curr_time_sec.millitm;                              // save running ms
        if (delay > 999) {
            dt = t + 999;                                       // force end ms to max
        }else {
            dt = t + delay;                                     // calc end ms
        }
        if (dt > 999) {
            st += 1;
            dt = dt - 1000;
        }
    }else {
        ct = curr_time_sec.millitm;
        if (((curr_time_sec.time == st) && (ct > dt)) || (curr_time_sec.time > st)) {
            loop = false;                                       // overrun, timer expired
        }else {                                                 // process the ms timer to see if timer expired...
            if (curr_time_sec.time == st) {
                if (dt > t) {
                    if ((ct > dt) || (ct < t)) loop = false;
                }
                else {
                    if ((ct > dt) && (ct < t)) loop = false;
                }
            }
        }
    }
    return loop;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// alive_timer_ms() is a ms timer dedicated to "I'm alive" status of the target device.
//  "delay" is in sec.
//
//  Returns FALSE if timer is expired, TRUE if running.
//
//  Call with delay value and SET = true to start timer.
//  Call with delay = "don't care" and SET = false to check timer.
//-----------------------------------------------------------------------------

bool alive_timer_sec(char delay, bool set) {
    __timeb64       curr_time_sec;      // current time
    static time_t   dt;                 // end (delta) time (sec)
    time_t          ct;                 // current time (sec)
    bool            loop = true;        // loop flag

    _ftime64_s(&curr_time_sec);
    if (set) {
        dt = curr_time_sec.time + (time_t)delay;            // save running seconds
    }else {
        ct = curr_time_sec.time;
        if (ct > dt) loop = false;
    }
    return loop;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// process_RXD() processes UART RXD data (cmd)
//  Capture quoted packets into stbuf[], post non-packet traffic to the term
//  window sector of the application window.
//  (row) points to the current row and is passed into and out of this Fn (caller
//  holds row for next pass through this Fn).
//
// Quote brackets operate on the principal that the data contained in the packet
//  can never produce either of the characters.  This requirement is enforced by
//  the remote device.
//-----------------------------------------------------------------------------
char process_RXD(char cmd, char row) {
    static  char    column;         // terminal display lateral character index
    static  char*   sptr;           // ibuf[] capture pointer
    static  char    qbuf[3];        // one chr string plus a buffer byte
    static  bool    pass1;          // first-pass flag
    static  bool    quoteo;         // status quote open
    static  int     stat_idx;       // status quote open
#define QUOTE_CLOSE '$'             // status packet "quote characters" as defined by Artemis RDU
#define QUOTE_OPEN  '#'

    if (row == CMD_INIT) {
        // init statics
        got_cr = 0;
        qbuf[0] = '\0';                                                 // preset puts string
        qbuf[1] = '\0';
        sptr = ibuf;
        *sptr = '\0';
        pass1 = 1;
        gopos(SERIAL_ROW - 1, 1);                                       // place window title
        clr_to_eol();
        set_text_color(ALERT_COLOR, BACK_COLOR);
        _cputs("TERMINAL WINDOW:");
        quoteo = false;
        stat_idx = 0;
        column = 1;
        return 0;
    }
/*    if (quoteo) {                                                       // quote open, store chrs to buff, strip quote characters
        if (cmd == QUOTE_CLOSE) {                                       // end of quoted packet
            got_stcr = true;                                            // clear quote trap
            quoteo = false;
        }else {
            stbuf[stat_idx++] = cmd;                                    // capture chr and walk the null
            stbuf[stat_idx] = '\0';
            if (stat_idx > MAX_STBUF) {                                 // stbuff full
                got_stcr = true;                                        // clear quote trap
                quoteo = false;
            }
        }
        return row;                                                     // exit init branch
    }*/
/*    if (cmd == QUOTE_OPEN) {                                            // begining of quoted packet
        quoteo = true;                                                  // open the status capture
        stat_idx = 0;                                                   // init capture string
        stbuf[0] = '\0';
    }else{*/
        if (supr_cr) {
            if ((cmd == '\n') || (cmd == '\r')) {
                supr_cr = false;
            }
            cmd = '\0';
        }
        if (((cmd >= ' ') || (cmd == '\n')) && (cmd < 0x7f)) {          // process printable chrs and newline
            if (sptr == ibuf) {                                         // clean-up rows if first chr in a line
                if ((row == SERIAL_ROW) && !pass1) {
                    // top row (not first pass)
                    gopos(BOTTOM_ROW + 1, 1);                           // clear bottom separator bar
                    clr_to_eol();
                    gopos(SERIAL_ROW + 1, 1);                           // clear top row
                    clr_to_eol();
                    set_text_color(ALERT_COLOR, BACK_COLOR);            // set new separator bar
                    _cputs("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                    column = 1;                                         // reset column index
                } else {
                    // all other rows or top row & first-pass
                    gopos(row, 1);                                      // clear current row
                    clr_to_eol();
                    gopos(row, 1);                                      // set new separator bar
                    set_text_color(ALERT_COLOR, BACK_COLOR);
                    _cputs("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                    column = 1;                                         // reset column index
                    pass1 = 0;                                          // clear first pass flag
                }
             }
            gopos(row, column);                                         // set new-chr location
            qbuf[0] = cmd;                                              // set string for puts
            *sptr++ = cmd;                                              // capture into long string
            *sptr = '\0';                                               // null terminate
            set_text_color(DATA_COLOR, BACK_COLOR);                     // display chr and advance column index
            _cputs(qbuf);
            column += 1;
        }
        if ((cmd == '\n') || (sptr >= (ibuf + MAX_IBUF - 1))) {         // newline or buffer full
            got_cr = 1;                                                 // send signal to process line
            column = 1;                                                 // advance row and reset column indecies
            row += 1;
            if (row > BOTTOM_ROW) {                                     // if bottom of window, wrap row back to top
                row = SERIAL_ROW;
            }
            sptr = ibuf;                                                // reset input pointer
        }
//    }
    return row;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// disp_stat() displays all internal param settings: T/R freq, VOl, SQUA, SQUB, hi/lo pwr
//-----------------------------------------------------------------------------
void disp_stat(char cmd) {
    int     i;

#define DU_CLS  0x7f

    if (cmd == DU_CLS) {
        set_text_color(LABEL_COLOR, BACK_COLOR);
        for (i = 0; i < NUM_STATUS_ROWS; i++) {
            gopos(STATUS_ROW + i, 1);                                           // clean status area before each command
            clr_to_eol();
            printf("%c", DPIPE);                                                // place "box" chrs
            gopos(STATUS_ROW + i, WINDOW_WIDTH_IN_CHARS);
            printf("%c", DPIPE);

        }
        gopos(STATUS_ROW, 2);
        set_text_color(STATUS_COLOR, BACK_COLOR);
        //              1         2         3         4         5         6         7         8
        //     12345678901234567890123456789012345678901234567890123456789012345678901234567890
        printf(" Artemis PC User Interface");
        gopos(STATUS_ROW + 1, 2);
    } else {
        set_text_color(DATA_COLOR, BACK_COLOR);
        //	#R<srf_main><srf_sub><cos/ptt><checkH><checkL>$<\n>
        // stow the cursor at the end of the prog status window
        gopos(PROG_ID_ROW, WINDOW_WIDTH_IN_CHARS-2);
    }
    return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// puts_rts() does a puts to the serial port with a bracketed rts enable/disable
//-----------------------------------------------------------------------------
void puts_rts(char* string) {

    // enable data out
//    set_rts(1);
//    timer_ms(50, 1);
//    while (timer_ms(0, 0));
    // send string
    putss(string, 1);
    // wait for transaction to complete
//    timer_ms(200, 1);
//    while (timer_ms(0, 0));
    // return to normal (allowing HM-133 to control radio)
//    set_rts(0);
    return;
}

// eof