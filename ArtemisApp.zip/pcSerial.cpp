/**
 *
 * @pcSerial.cpp
 *
 * Serial input and output function declarations.
 *
 */


#include "stdafx.h"

#include <windows.h>
#include "pcSerial.h"
#include "uxpll.h"					// for timer_ms() support

static HANDLE hComPort;             // handle for PC com port
static DCB  dcb;                    // port config structure


// ===========================================================================
//
// configCommPort - documentation in header.
//
// ===========================================================================
bool configCommPort(BYTE port, long baudRate, BYTE parity, BYTE byteSize,
                  BYTE stopBits)
{
    bool success = false;          // return value
    char portName[32];              // com port "name"
    COMMTIMEOUTS commTimeouts;

    sprintf_s(portName, 10, "\\\\.\\COM%d", port);
    hComPort = CreateFile(portName, GENERIC_READ+GENERIC_WRITE, 0,
                          NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

    if (hComPort != INVALID_HANDLE_VALUE)
    {
        // Configure the COM Port
        dcb.DCBlength = sizeof(dcb);
        if (GetCommState(hComPort, &dcb))
        {
            dcb.BaudRate = baudRate;
            dcb.Parity   = parity;
            dcb.ByteSize = byteSize;
            dcb.StopBits = stopBits;
            dcb.fOutxCtsFlow = 0;
            dcb.fOutxDsrFlow = 0;
            dcb.fDtrControl  = DTR_CONTROL_ENABLE;
            dcb.fRtsControl = RTS_CONTROL_DISABLE;

            if (SetCommState(hComPort, &dcb))
            {
                // Establish Driver buffer sizes
                //if (SetupComm(hComPort, 1024, 1024))
                if (SetupComm(hComPort, 32768, 1024))
                {
                    if (GetCommTimeouts(hComPort, &commTimeouts))
                    {
                        commTimeouts.ReadIntervalTimeout        = MAXDWORD;
                        commTimeouts.ReadTotalTimeoutMultiplier = MAXDWORD;
                        commTimeouts.ReadTotalTimeoutConstant   = 250;
                        commTimeouts.WriteTotalTimeoutMultiplier  = 0;
                        commTimeouts.WriteTotalTimeoutConstant    = 0;

                        if (SetCommTimeouts(hComPort, &commTimeouts))
                        {
                            success = true;
                        }
                        else
                        {
                            printf("Set CommTimeouts() failed.\n");
                        }
                    }
                    else
                    {
                       printf("Get CommTimeouts() failed.\n");
                    }
                }
                else
                {
                   printf("SetupComm() failed.\n");
                }
            }
            else
            {
                printf("SetCommState() failed.\n");
            }
        }
        else
        {
            printf("GetCommState() failed.\n");
        }
    }
    else
    {
        printf("COM Port open failed (%s).\n", portName);
    }
    return(success);
}

// ===========================================================================
//
// set_rts - set/clear rts
//
// ===========================================================================
bool set_rts(bool rts_enable)
{
    bool success = false;          // return value

    if (hComPort != INVALID_HANDLE_VALUE)
    {
        // re-configure the COM Port RTS
        dcb.DCBlength = sizeof(dcb);
        if (GetCommState(hComPort, &dcb))
        {
            /*            dcb.BaudRate = baudRate;
                        dcb.Parity = parity;
                        dcb.ByteSize = byteSize;
                        dcb.StopBits = stopBits;
                        dcb.fOutxCtsFlow = 0;
                        dcb.fOutxDsrFlow = 0;
                        dcb.fDtrControl = DTR_CONTROL_ENABLE;*/
            if (rts_enable) {
                dcb.fRtsControl = RTS_CONTROL_ENABLE;
            }
            else {
                dcb.fRtsControl = RTS_CONTROL_DISABLE;
            }

            if (SetCommState(hComPort, &dcb))
            {
                success = true;
            }
        }
    }
    return(success);
}


// ===========================================================================
//
// closeCommPort - documentation in header.
//
// ===========================================================================
void closeCommPort(void)
{
    CloseHandle(hComPort);
}


// ===========================================================================
//
// sendByte - documentation in header.
//
// ===========================================================================
void sendByte(char c)
{
    static DWORD bytesOut = 1;
    static char buf[10];

    buf[0] = c;
    buf[1] = '\0';
    WriteFile(hComPort, buf, 1, &bytesOut, NULL);
}


// ===========================================================================
//
// serialByteIn - documentation in header.
//
// ===========================================================================
bool serialByteIn(char *c)
{
    DWORD numBytesIn = 0;          // number of bytes received
    bool  byteReceived = false;    // return value

    if (ReadFile(hComPort, c, 1, &numBytesIn, NULL))
    {
        if (numBytesIn == 1)
        {
            byteReceived = true;
        }
    }
    return(byteReceived);
}


//-----------------------------------------------------------------------------
// putss() does puts w/o newline
//-----------------------------------------------------------------------------

void putss(char* string, int delay)
{
    char* sptr = string;

    while (*sptr) {
        if (*sptr == '\n') {
            sendByte('\r');
//            timer_ms(delay, 1);
//            while (timer_ms(0, 0));
        }
        sendByte(*sptr++);
//        timer_ms(delay, 1);
//        while (timer_ms(0, 0));
    }
    return;
}

//-----------------------------------------------------------------------------
// getss() puts data into an array (via a passed pointer) until '\n' is encountered
//	timer_ms() limits the dwell here to 400 ms so that the SW can't get locked up
//	waiting for a non-existant target.
//
//	*string points to return array of char
//	max_chrs is the max size of the return array.  getss() will fetch up to
//		"max_chrs - 1" characters (leaves room for null terminator).
//		minimum chr count is 2.
//-----------------------------------------------------------------------------
char* getss(char* string, char max_chrs)
 {
    char* sptr = string;
    char    ch = '\0';
	char	max_count;
    bool    ischr;

	if(max_chrs <= 2){
		max_count = 2;
	}else{
		max_count = max_chrs - 1;
	}
    timer_ms(400, true);
    do {
        ischr = serialByteIn(&ch);
        if (ischr) {
            *sptr++ = ch;
			max_count -= 1;
        }

//    } while (ch != '\n');
    } while (timer_ms(0, false) && (ch != '\n') && (max_count != 0));
    *sptr = '\0';
    return sptr;
}



