#pragma once

#define ALIVE_TIME	4					// alive timeout
#define SET_TIMER	1					// set timer cmd
#define READ_TIMER	0					// read timer cmd

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// external function prototypes
//-----------------------------------------------------------------------------

bool timer_ms(short int delay, bool set);
