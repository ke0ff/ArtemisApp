#define  LABEL_COLOR       LIGHTCYAN
#define  DATA_COLOR        WHITE
#define  BACK_COLOR        BLACK
#define  WARN_COLOR        YELLOW
#define  ALERT_COLOR       LIGHTRED
#define  INPUT_COLOR       GREEN
#define  STATUS_COLOR      LIGHTGREEN

#define  TOP_ROW		   1
#define  PROG_ID_ROW       (TOP_ROW + 1)
#define	 NUM_STATUS_ROWS   1								// 11 rows for status
#define  STATUS_ROW        (PROG_ID_ROW + 2)
#define  MENU_ROW_1        (STATUS_ROW + NUM_STATUS_ROWS)
#define  MENU_ROW_2        (MENU_ROW_1 + 1)
#define  MENU_ROW_3        (MENU_ROW_2 + 1)
#define  MENU_ROW_4        (MENU_ROW_3 + 1)
#define  MENU_ROW_5        (MENU_ROW_4 + 1)
#define  MENU_ROW_6        (MENU_ROW_5 + 1)
/*#define  MENU_ROW_7        (MENU_ROW_6 + 1)
#define  MENU_ROW_8        (MENU_ROW_7 + 1)
#define  MENU_ROW_9        (MENU_ROW_8 + 1)
#define  MENU_ROW_10       (MENU_ROW_9 + 1)
#define  MENU_ROW_11       (MENU_ROW_10 + 1)*/
#define  LAST_MENU_ROW     MENU_ROW_6

#define  INPUT_ROW         (LAST_MENU_ROW+1)
#define  SERIAL_ROW		   (LAST_MENU_ROW+5)
#define  OUTPUT_ROW        (LAST_MENU_ROW+7)
#define  BOTTOM_ROW        (LAST_MENU_ROW+36)

#define  SCROLL_ROW        (INPUT_ROW+3)
#define  LAST_SCROLL_ROW   (SCROLL_ROW+35)

#define  WINDOW_WIDTH_IN_CHARS  95 //86
#define  WINDOW_LENGTH_IN_LINES (48)
#define  TR_STATUS_COL		  (WINDOW_WIDTH_IN_CHARS - 16)
#define  TR_STATUS_WIN_COL    (WINDOW_WIDTH_IN_CHARS - 20)

#define	DBAR	0xcd
#define	ULDBAR	0xc9
#define	LLDBAR	0xc8
#define	URDBAR	(LLDBAR - 13)
#define	LRDBAR	(LLDBAR - 12)
#define	UDBAR	0xca
#define	DDBAR	0xcb
#define	DPIPE	0xba
#define	LDPIPE	(LLDBAR + 4)
#define	RDPIPE	(LLDBAR - 15)
#define	CPYRT	0xa9


/*
SerialTest version 4.3 on comm 9  --  ESC to quit

<S> Set Switch #    <R> Redraw screen
<0> CLOSE_FET   <1> OPEN_FET          <2> ARM                  <3> FIRE
<4> DISARM      <5> QUIET_SWITCH      <6> CLOSE_FET_GO_QUIET   <7> SWITCH_VER
<8> PANEL_VER   <9> POWER_GUNSTRING   <A> ADC_MEAS             <Q> QUERY_STATUS
<B> QUERY_LIFE  <C> ARM_TOOL          <D> FIRE_TOOL            <E> DISARM_TOOL
<F> PWRSUPPLY_V_PROFILE               <G> PWRSUPPLY_C_PROFILE  <T> String Test

# of switches found: 70      Test In Progress (press 'T' again to abort)

top of scroll
2
3
4
5
6
7
8
9
10
11
12
13
14
15


*/

